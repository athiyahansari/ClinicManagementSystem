﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMS.View.Admin
{
    public partial class ManageDoctors : Form
    {
        public ManageDoctors()
        {
            InitializeComponent();
        }

        private void emailtxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void phoneNotxt_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
